# CATATAN ( NOTE )
Mulai saat ini, script ini tidak akan dilanjutkan lagi, jika ingin menambah sesuatu lebih baik dibuat pribadi aja, malah keren itu lhu punya tapi yang lain kaga jadi lhu bisa jual tu fitur kalo di publik di script ini mungkin kalian akan rugi sendiri, sudah susah-susah bikin code tapi malah dijual Ama yang cuma modal nyomot doang & dibuat konten yt, yutuber untung yang buat kaga, tapi terserah kalian juga kalo mau pull ya tetep saya ACC

Kalo mau jualan normal aja, jangan sampe nipu atau memberi harapan kosong, contohnya "dijual fitur langkah ada storenya 😱", gabaik itu, mau untung boleh tapi jangan sampe merugikan orang lain 

Best Regards

<p align="center">
<img src="https://telegra.ph/file/1537b118bad59ab8fa15e.png" alt="Adrian-MD" width="500"/>
</p>
<h1 align="center">Adrian-MD</h1>
<p align="center">
  <a href="https://github.com/AdrianTzy"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Adrian+Multi+Device;Base+AdrianTzy;Give+star+and+forks+this+Repo+:D;Follow+My+Github" alt="UwU">
</p>

---------

# Media Sosial Bot
<p align="center">
  <a href="https://wa.me/6282116863163?text=Menu"><img src="https://img.shields.io/badge/WhatsApp%20Bot-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/>
  <a href="https://chat.whatsapp.com/DRCrPjaOXcZ9tXbx2raQ10"><img src="https://img.shields.io/badge/WhatsApp%20Grup-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"></a>
</p>

---------

# Note
This Script is for everyone, not for Sale. Jika dijual neraka menunggumu brother !

## Heroku Buildpack
<p align="center">
  <a href="https://heroku.com/deploy?template=https://github.com/AdrianTzy/Adrian-MD"><img src="https://www.herokucdn.com/deploy/button.svg"/> 
  <a href="https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest"><img src="https://img.shields.io/badge/BuildPack%20FFMPEG-9370DB?style=for-the-badge&logo=heroku&logoColor=white">
  <a href="https://github.com/clhuang/heroku-buildpack-webp-binaries.git"><img src="https://img.shields.io/badge/BuildPack%20IMAGEMAGICK-9370DB?style=for-the-badge&logo=heroku&logoColor=white"></a>
</p>

## Okteto
<p align="center">
  <a href="https://cloud.okteto.com"><img src="https://okteto.com/develop-okteto.svg"></a>
</p>

```bash
Login with your github
Click Launch Dev Environment
Choose your repo
```

---------

## Untuk Pengguna Windows/rdp

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)

```bash
git clone https://github.com/AdrianTzy/Adrian-MD
cd Adrian-MD
npm install
```

## For Termux/ubuntu/ssh User

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/AdrianTzy/Adrian-MD
cd Adrian-MD
npm install
```

## Recommended Install On Termux

```bash
pkg install yarn
yarn
```

## Installing
```bash
$ node .
```

---------

# ❗ Warning
WhatsApp bot is still in the development stage, so there are a few bugs
WhatsApp Connection (BETA, not working perfectly)

Editing Number Owner & session name in [`config.js`](https://github.com/AdrianTzy/Adrian-MD/blob/master/config.js)

```How To Customise Message Display```
```js
//—————「 Website Apikey 」—————//
global.APIs = {
    zenz: 'https://api.zahwazein.xyz'
}

//—————「 Website Apikey 」—————//
global.APIKeys = {
    'https://api.zahwazein.xyz': 'zenzkey_ad0a9acee99f'
}

//—————「 Set Nama Bot & Own 」—————//
global.namabot = '𝙰𝙳𝚁𝙸𝙰𝙽-𝙼𝙳'
global.namaowner = '𝙰𝙳𝚁𝙸𝙰𝙽'

//—————「 Setting Owner 」—————//
global.owner = ['6289513081052']
global.ownernomer = "6289513081052"
global.premium = ['6289513081052']
global.ultah = 'Maret 24, 2024'

//—————「 Setting Donasi 」—————//
global.dana = '089513081052'

//—————「 Set Kebutuhan Button 」—————//
global.email = 'azzygota24@gmail.com'
global.namaweb = 'TikTok'
global.myweb = 'https://tiktok.com/@dryan.am'
global.region = 'Indonesia'
global.github = 'https://github.com/AdrianTzy'
global.mygc = 'https://chat.whatsapp.com/DRCrPjaOXcZ9tXbx2raQ10'
global.myig = 'https://instagram.com/dryan.pu'

//—————「 Set Wm 」—————//
global.packname = '𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝙱𝚈 𝙰𝙳𝚁𝙸𝙰𝙽𝙱𝙾𝚃\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
global.author = '𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰 𝚂𝚄𝙱𝚂𝙲𝚁𝙸𝙱𝙴\n𝚈𝚃:𝙳𝚁𝚈𝙰𝙽𝙱𝙾𝚃'

//—————「 Set Nama Session 」—————//
//gausah di apa² ini!
global.sessionName = 'session'

//—————「 Set Prefix 」—————//
//gausah di apa² ini!
global.jumlha = '999'
global.jumhal = '100000000000000'
global.jumlah = '1000000000'
global.prefa = ['', '!', '.', '#', '$', ',']

//—————「 Set Simbol 」—————//
global.sp = '•'

//—————「 Set Message 」—————//
global.mess = {
    success: '🤗Done, Oke Desu~',
    admin: '❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !',
    botAdmin: '❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !',
    group: '❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !',
    private: '❗Perintah Ini Hanya Bisa Digunakan Di Private Chat !',
    bot: '🤖 Fitur Khusus Pengguna Nomor Bot !',
    wait: '⏳ Sedang Di Proses !',
    endLimit: '🕊️ Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12 !',
    error: '🚫 Fitur Sedang Error !',
}

//—————「 Set Limit 」—————//
//terserah mau ubah atau nggak
global.limitawal = {
    premium: "Infinity",
    free: 50,
}

//—————「 Set Image 」—————//
global.thumb = fs.readFileSync('./media/image/adrian.jpg')
global.kurome = { url: 'https://a.uguu.se/faLPPBPP.mp4' }
global.botname = 'AdrianTzy Creator'
global.akulaku = 'Bot By AdrianTzy'
global.ttname = 'TikTok AdrianTzy'

//—————「 Set Random Image Menu 」—————//
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.mehk = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='
global.awog = 'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text='
global.mohai = 'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text='
global.mhehe = 'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text='

```
---------

# Apikey
* Get Apikey zenz on [`Zenz`](https://api.zahwazein.xyz/)

## Thanks To
* [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)
* [`Nurutomo`](https://github.com/Nurutomo)
* [`Mhankbarbar`](https://github.com/MhankBarBar)
* [`Faiz`](https://github.com/FaizBastomi)
* [`Gimenz`](https://github.com/Gimenz)
* [`rayy`](https://github.com/rayyreall)
* [`AdrianTzy`](https://github.com/AdrianTzy)
* [`GuaAbuzz`](https://github.com/Abuzzpoet)
* [`FatihArridho`](https://github.com/FatihArridho)
* [`Pa7rick`](https://github.com/pa7rickr)
* [`RidhoUhuy`](https://github.com/Atak676) 
* [`zhwzein`](https://github.com/zhwzein)
* [`CAF-ID`](https://github.com/CAF-ID)
* [`bintang`](https://github.com/Bintangp02)

```Thanks to all who have participated in the development of this script```


License: [MIT](https://en.wikipedia.org/wiki/MIT_License)